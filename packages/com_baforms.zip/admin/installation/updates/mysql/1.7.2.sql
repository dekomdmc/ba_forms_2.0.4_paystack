ALTER TABLE `#__baforms_forms` ADD COLUMN `save_submissions` tinyint(1) NOT NULL DEFAULT 1;
ALTER TABLE `#__baforms_forms` ADD COLUMN `attach_uploaded_files` tinyint(1) NOT NULL DEFAULT 1;