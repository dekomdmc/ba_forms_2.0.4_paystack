ALTER TABLE `#__baforms_forms` ADD COLUMN `acym_lists` text NOT NULL;
ALTER TABLE `#__baforms_forms` ADD COLUMN `acym_fields_map` text NOT NULL;