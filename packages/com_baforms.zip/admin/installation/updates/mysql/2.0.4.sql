INSERT INTO `#__baforms_api` (`service`, `key`) VALUES
('payfast', '{"merchant_id":"","merchant_key":"","environment":"","return_url":""}'),
('paypal_sdk', '{"client_id":"","return_url":""}');