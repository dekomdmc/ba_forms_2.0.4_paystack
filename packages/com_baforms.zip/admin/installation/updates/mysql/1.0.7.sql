ALTER TABLE `#__baforms_forms` ADD COLUMN `display_submit` tinyint(1) NOT NULL DEFAULT 1;  
