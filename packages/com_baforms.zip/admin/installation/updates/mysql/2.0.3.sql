INSERT INTO `#__baforms_api` (`service`, `key`) VALUES
('payu_latam', '{"api_key":"","merchant_id":"","account_id":"","environment":"","return_url":""}'),
('yandex_kassa', '{"shop_id":"","scid":"","environment":"","return_url":""}'),
('redsys', '{"merchant":"","transaction":"","terminal":"","signature":"","return_url":""}');